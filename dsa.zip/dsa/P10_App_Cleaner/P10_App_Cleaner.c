#include <stdio.h>
#include <string.h>

struct App {
    char name[20];
    int frequency;
    int installed;
};

int findApp(struct App apps[], int size, const char* name) {
    int i;
    for (i = 0; i < size; i++) {
        if (apps[i].installed && strcmp(apps[i].name, name) == 0) {
            return i;
        }
    }
    return -1;
}

void openApp(struct App apps[], int size, const char* name) {
    int idx = findApp(apps, size, name);
    int i;
    if (idx == -1) {
        for (i = 0; i < size; i++) {
            if (!apps[i].installed) {
                strcpy(apps[i].name, name);
                apps[i].frequency = 1;
                apps[i].installed = 1;
                printf("Installed new app: %s\n", name);
                return;
            }
        }
        printf("No space to install new app: %s\n", name);
    } else {
        apps[idx].frequency++;
        printf("Opened app: %s, new frequency: %d\n", name, apps[idx].frequency);
    }
}

void uninstallLeastUsedApps(struct App apps[], int size, int uninstallCount) {
    int u, i;
    for (u = 0; u < uninstallCount; u++) {
        int minFreq = 1000000;
        int idxToRemove = -1;
        for (i = 0; i < size; i++) {
            if (apps[i].installed && apps[i].frequency < minFreq) {
                minFreq = apps[i].frequency;
                idxToRemove = i;
            }
        }
        if (idxToRemove == -1) {
            printf("No more apps to uninstall.\n");
            break;
        }
        printf("Uninstalling app: %s with frequency %d\n", apps[idxToRemove].name, apps[idxToRemove].frequency);
        apps[idxToRemove].installed = 0;
        apps[idxToRemove].frequency = 0;
        apps[idxToRemove].name[0] = '\0';
    }
}

void printApps(struct App apps[], int size) {
    int i;
    printf("Installed apps:\n");
    for (i = 0; i < size; i++) {
        if (apps[i].installed) {
            printf("App: %s, Frequency: %d\n", apps[i].name, apps[i].frequency);
        }
    }
    printf("\n");
}

int main() {
    struct App apps[10] = {0};

    openApp(apps, 10, "Facebook");
    openApp(apps, 10, "Twitter");
    openApp(apps, 10, "Facebook");
    openApp(apps, 10, "Instagram");
    openApp(apps, 10, "Facebook");
    openApp(apps, 10, "Twitter");

    printApps(apps, 10);

    uninstallLeastUsedApps(apps, 10, 2);

    printApps(apps, 10);

    return 0;
}
