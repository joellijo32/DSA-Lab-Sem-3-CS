#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>

#define MAX_TERMS 100

typedef struct Term
{
  int coeff; int exp;
} Term;


typedef struct Poly {
  
  Term terms[MAX_TERMS];
  int size;

} Poly;


Poly *readP()
{
  Poly *p = malloc(sizeof(Poly));
  int terms;
  printf("Enter # of terms:");
  scanf("%d", &terms);
  p->size = terms;

  for (int i = 0; i < terms; i++)
  {
    int coeff, exp;
    printf("Enter #%dth term (coeff exp):", i);
    scanf("%d %d", &coeff, &exp);
    Term t = {.coeff = coeff, .exp = exp};
    p->terms[i] = t;
  }
  return p;
}
void printP(Poly *p)
{
  assert( p != NULL);
  for (int i = 0; i < p->size - 1; i++)
  {
    int coeff = p->terms[i].coeff, exp = p->terms[i].exp;
    if (coeff != 0 && exp != 0)
     printf("%dx^%d + ", coeff, exp);
    else if (exp == 0)
      printf("%d + ", coeff);
  }
  int coeff = p->terms[p->size - 1].coeff, exp = p->terms[p->size-1].exp;
  if (coeff != 0 && exp != 0)
    printf("%dx^%d", coeff, exp);
  printf("\n");
}

void addTerm(Term t, Poly *p)
{
  assert( p != NULL);
  bool foundExp = false;

  for (int i = 0; i < p->size; i++)
  {
    Term oldTerm = p->terms[i];
    if (t.exp == oldTerm.exp)
    {
      foundExp = true;
      p->terms[i].coeff += t.coeff;
    }
  }

  if (!foundExp) {
    p->terms[p->size++] = t;
  }
}


Poly * multiply(Poly *p1, Poly *p2) 
{

  assert(p1 != NULL && p2 != NULL);
  Poly *p = malloc(sizeof(Poly));
  p->size = 0;

  for (int i = 0; i < p1->size; i++)
  {
    for (int j = 0; j < p2->size; j++)
    {
      int  newCoeff = p1->terms[i].coeff * p2->terms[j].coeff;
      int  newExp = p1->terms[i].exp + p2->terms[j].exp;
      Term t = {.coeff = newCoeff, .exp = newExp};
      addTerm(t, p);

    }
  }

  return p;

}

void main()
{
  printf("-- Reading P1 --- \n");
  Poly *p1 = readP();
  printP(p1);
  printf("-- Reading P2 --- \n");
  Poly *p2 = readP();
  printP(p2);

  Poly *result = multiply(p1, p2);
  printf("Polynomial Multiplication Output:");
  printP(result);

}
