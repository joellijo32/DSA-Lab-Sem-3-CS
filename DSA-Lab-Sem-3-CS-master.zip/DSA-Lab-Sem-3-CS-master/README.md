# DSA-Lab-Sem-3-CS
The DSA Problems and Solutions done for my B.tech Semester 3 Lab . (Please Ignore the .exe files and run only the .c file 🙂)
Here's the questions: 

[PCCSL307 Lab cycle (1).pdf](https://github.com/user-attachments/files/21514727/PCCSL307.Lab.cycle.1.pdf)
[PCCSL307 Lab cycle.pdf](https://github.com/user-attachments/files/21514730/PCCSL307.Lab.cycle.pdf)
